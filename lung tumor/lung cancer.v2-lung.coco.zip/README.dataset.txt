# lung cancer > lung
https://universe.roboflow.com/object-detection/lung-cancer-isz16

Provided by Roboflow
License: CC BY 4.0

